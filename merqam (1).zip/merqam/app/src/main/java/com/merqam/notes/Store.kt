package com.merqam.notes

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Note(
    val id: String,
    var title: String,
    var pages: MutableList<MutableList<Stroke>>,
    var updated: Long = System.currentTimeMillis()
)

object Store {
    private fun dir(ctx: Context) = File(ctx.filesDir, "notes").apply { mkdirs() }

    fun create(ctx: Context, title: String): Note {
        val n = Note(System.currentTimeMillis().toString(), title, mutableListOf(mutableListOf()))
        save(ctx, n)
        return n
    }

    fun list(ctx: Context): List<Note> =
        (dir(ctx).listFiles() ?: emptyArray())
            .filter { it.extension == "json" }
            .mapNotNull { load(ctx, it.nameWithoutExtension) }
            .sortedByDescending { it.updated }

    fun load(ctx: Context, id: String): Note? = try {
        val o = JSONObject(File(dir(ctx), "$id.json").readText())
        val pages = mutableListOf<MutableList<Stroke>>()
        val pa = o.getJSONArray("pages")
        for (i in 0 until pa.length()) {
            val strokes = mutableListOf<Stroke>()
            val sa = pa.getJSONArray(i)
            for (j in 0 until sa.length()) {
                val so = sa.getJSONObject(j)
                val pts = mutableListOf<Float>()
                val p = so.getJSONArray("p")
                for (k in 0 until p.length()) pts.add(p.getDouble(k).toFloat())
                strokes.add(Stroke(so.getInt("c"), so.getDouble("w").toFloat(), pts))
            }
            pages.add(strokes)
        }
        if (pages.isEmpty()) pages.add(mutableListOf())
        Note(id, o.getString("title"), pages, o.optLong("updated", 0L))
    } catch (e: Exception) { null }

    fun save(ctx: Context, n: Note) {
        val pa = JSONArray()
        for (page in n.pages) {
            val sa = JSONArray()
            for (s in page) {
                val p = JSONArray()
                s.pts.forEach { p.put(it.toDouble()) }
                sa.put(JSONObject().put("c", s.color).put("w", s.width.toDouble()).put("p", p))
            }
            pa.put(sa)
        }
        val o = JSONObject().put("title", n.title).put("updated", n.updated).put("pages", pa)
        File(dir(ctx), "${n.id}.json").writeText(o.toString())
    }

    fun delete(ctx: Context, id: String) { File(dir(ctx), "$id.json").delete() }
}

package com.merqam.notes

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.format.DateFormat
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.util.Date

class MainActivity : Activity() {

    private lateinit var listBox: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF4F6FA.toInt())
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "مرقم"
            textSize = 30f
            setTextColor(0xFF1B2A41.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(12))
        })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(listBox) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(Button(this).apply {
            text = "＋ دفتر جديد"
            textSize = 18f
            setOnClickListener { askTitle("دفتر جديد", "") { t -> openNote(Store.create(this@MainActivity, t).id) } }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        listBox.removeAllViews()
        val notes = Store.list(this)
        if (notes.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "مفيش دفاتر لسه. اضغطي \"دفتر جديد\" وابدأي الكتابة بالقلم."
                textSize = 16f; gravity = Gravity.CENTER
                setPadding(dp(16), dp(48), dp(16), dp(16))
            })
        }
        for (n in notes) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(16), dp(18), dp(16))
                background = GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius = dp(14).toFloat()
                    setStroke(dp(1), 0xFFDDE3EE.toInt())
                }
            }
            card.addView(TextView(this).apply { text = n.title; textSize = 20f; setTextColor(0xFF1B2A41.toInt()) })
            card.addView(TextView(this).apply {
                text = "${n.pages.size} صفحة • " + DateFormat.format("yyyy/MM/dd  hh:mm a", Date(n.updated))
                textSize = 13f; setTextColor(0xFF7A869A.toInt())
            })
            card.setOnClickListener { openNote(n.id) }
            card.setOnLongClickListener { options(n); true }
            listBox.addView(card, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
        }
    }

    private fun options(n: Note) {
        AlertDialog.Builder(this).setTitle(n.title)
            .setItems(arrayOf("تغيير الاسم", "حذف")) { _, which ->
                if (which == 0) askTitle("اسم الدفتر", n.title) { t ->
                    n.title = t; Store.save(this, n); refresh()
                } else AlertDialog.Builder(this).setMessage("تحذفي \"${n.title}\"؟")
                    .setPositiveButton("حذف") { _, _ -> Store.delete(this, n.id); refresh() }
                    .setNegativeButton("إلغاء", null).show()
            }.show()
    }

    private fun askTitle(title: String, initial: String, ok: (String) -> Unit) {
        val et = EditText(this).apply { setText(initial); hint = "اسم الدفتر"; setSingleLine() }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("تمام") { _, _ ->
                ok(et.text.toString().trim().ifEmpty { "دفتر بدون اسم" })
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun openNote(id: String) {
        startActivity(Intent(this, EditorActivity::class.java).putExtra("id", id))
    }
}

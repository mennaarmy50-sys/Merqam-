package com.merqam.notes

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/** نقاط الخط مخزنة بوحدة dp: x0,y0,x1,y1,... */
class Stroke(val color: Int, val width: Float, val pts: MutableList<Float> = mutableListOf())

class DrawingView(ctx: Context) : View(ctx) {

    var strokes: MutableList<Stroke> = mutableListOf()
        set(v) { field = v; undoStack.clear(); redoStack.clear(); invalidate() }
    var penColor = Color.BLACK
    var penWidth = 2.5f
    var eraser = false
    /** لو false: القلم بس بيكتب واللمس بالإصبع/الكف بيتتجاهل (رفض الكف) */
    var fingerDraw = false
    var onChanged: (() -> Unit)? = null

    private val d = resources.displayMetrics.density

    private sealed class Op {
        class Add(val s: Stroke) : Op()
        class Remove(val items: List<Pair<Int, Stroke>>) : Op()
    }

    private val undoStack = ArrayList<Op>()
    private val redoStack = ArrayList<Op>()
    private var cur: Stroke? = null
    private var pointerId = -1
    private var erasing = false
    private val removed = ArrayList<Pair<Int, Stroke>>()

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ruled = Paint().apply { color = 0xFFE3E8F0.toInt(); strokeWidth = 1f }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.WHITE)
        var y = 36f * d
        while (y < height) { c.drawLine(0f, y, width.toFloat(), y, ruled); y += 32f * d }
        for (s in strokes) drawStroke(c, s)
        cur?.let { drawStroke(c, it) }
    }

    private fun drawStroke(c: Canvas, s: Stroke) {
        val n = s.pts.size / 2
        if (n == 0) return
        if (n == 1) {
            dot.color = s.color
            c.drawCircle(s.pts[0] * d, s.pts[1] * d, s.width * d / 2, dot)
            return
        }
        paint.color = s.color
        paint.strokeWidth = s.width * d
        val p = Path()
        p.moveTo(s.pts[0] * d, s.pts[1] * d)
        for (i in 1 until n) {
            val px = s.pts[(i - 1) * 2] * d
            val py = s.pts[(i - 1) * 2 + 1] * d
            val x = s.pts[i * 2] * d
            val y = s.pts[i * 2 + 1] * d
            p.quadTo(px, py, (px + x) / 2, (py + y) / 2)
        }
        p.lineTo(s.pts[(n - 1) * 2] * d, s.pts[(n - 1) * 2 + 1] * d)
        c.drawPath(p, paint)
    }

    private fun accepts(e: MotionEvent, i: Int): Boolean {
        val t = e.getToolType(i)
        return t == MotionEvent.TOOL_TYPE_STYLUS ||
            t == MotionEvent.TOOL_TYPE_ERASER ||
            t == MotionEvent.TOOL_TYPE_MOUSE ||
            (fingerDraw && t == MotionEvent.TOOL_TYPE_FINGER)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                if (pointerId == -1 && accepts(e, i)) {
                    pointerId = e.getPointerId(i)
                    begin(e.getX(i), e.getY(i), e.getToolType(i))
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val i = e.findPointerIndex(pointerId)
                if (i >= 0) {
                    for (h in 0 until e.historySize) addPoint(e.getHistoricalX(i, h), e.getHistoricalY(i, h))
                    addPoint(e.getX(i), e.getY(i))
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                if (pointerId != -1 && e.getPointerId(e.actionIndex) == pointerId) {
                    finish(); pointerId = -1
                }
            }
            MotionEvent.ACTION_CANCEL -> { finish(); pointerId = -1 }
        }
        return true
    }

    private fun begin(x: Float, y: Float, tool: Int) {
        erasing = eraser || tool == MotionEvent.TOOL_TYPE_ERASER
        if (erasing) {
            removed.clear()
            eraseAt(x / d, y / d)
        } else {
            cur = Stroke(penColor, penWidth).also { it.pts.add(x / d); it.pts.add(y / d) }
        }
        invalidate()
    }

    private fun addPoint(x: Float, y: Float) {
        if (erasing) eraseAt(x / d, y / d)
        else cur?.let { it.pts.add(x / d); it.pts.add(y / d) }
    }

    private fun finish() {
        if (erasing) {
            if (removed.isNotEmpty()) push(Op.Remove(removed.toList()))
            removed.clear()
            erasing = false
        } else {
            cur?.let { strokes.add(it); push(Op.Add(it)) }
        }
        cur = null
        invalidate()
    }

    private fun push(op: Op) {
        undoStack.add(op); redoStack.clear(); onChanged?.invoke()
    }

    private fun eraseAt(x: Float, y: Float) {
        val r = 14f
        for (i in strokes.indices.reversed()) {
            val s = strokes[i]
            var hit = false
            var k = 0
            while (k < s.pts.size) {
                if (hypot(s.pts[k] - x, s.pts[k + 1] - y) < r) { hit = true; break }
                k += 2
            }
            if (hit) { strokes.removeAt(i); removed.add(i to s) }
        }
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val op = undoStack.removeAt(undoStack.size - 1)
        when (op) {
            is Op.Add -> strokes.remove(op.s)
            is Op.Remove -> for ((idx, s) in op.items.reversed()) strokes.add(min(idx, strokes.size), s)
        }
        redoStack.add(op); onChanged?.invoke(); invalidate()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val op = redoStack.removeAt(redoStack.size - 1)
        when (op) {
            is Op.Add -> strokes.add(op.s)
            is Op.Remove -> op.items.forEach { (_, s) -> strokes.remove(s) }
        }
        undoStack.add(op); onChanged?.invoke(); invalidate()
    }

    fun clearAll() {
        if (strokes.isEmpty()) return
        val items = strokes.mapIndexed { i, s -> i to s }
        strokes.clear()
        push(Op.Remove(items)); invalidate()
    }
}

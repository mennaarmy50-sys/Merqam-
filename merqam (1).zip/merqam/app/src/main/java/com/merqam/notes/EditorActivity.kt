package com.merqam.notes

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class EditorActivity : Activity() {

    private lateinit var note: Note
    private lateinit var canvas: DrawingView
    private lateinit var pageLabel: TextView
    private lateinit var penBtn: TextView
    private lateinit var eraserBtn: TextView
    private lateinit var fingerBtn: TextView
    private var page = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val loaded = Store.load(this, intent.getStringExtra("id") ?: "")
        if (loaded == null) { finish(); return }
        note = loaded

        canvas = DrawingView(this)
        canvas.onChanged = { note.updated = System.currentTimeMillis() }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        bar.addView(tool("→") { saveNow(); finish() })
        bar.addView(tool("↶") { canvas.undo() })
        bar.addView(tool("↷") { canvas.redo() })
        penBtn = tool("✏️") { canvas.eraser = false; refreshTools() }
        eraserBtn = tool("🧽") { canvas.eraser = true; refreshTools() }
        bar.addView(penBtn); bar.addView(eraserBtn)

        for (c in intArrayOf(Color.BLACK, 0xFF1565C0.toInt(), 0xFFD32F2F.toInt(), 0xFF2E7D32.toInt(), 0xFFEF6C00.toInt())) {
            bar.addView(tool("●", c) { canvas.penColor = c; canvas.eraser = false; refreshTools() })
        }
        bar.addView(tool("╌") { canvas.penWidth = 1.5f })
        bar.addView(tool("─") { canvas.penWidth = 2.5f })
        bar.addView(tool("━") { canvas.penWidth = 5f })

        fingerBtn = tool("✋") {
            canvas.fingerDraw = !canvas.fingerDraw
            refreshTools()
            Toast.makeText(this, if (canvas.fingerDraw) "الكتابة بالإصبع شغالة" else "القلم بس بيكتب (رفض الكف)", Toast.LENGTH_SHORT).show()
        }
        bar.addView(fingerBtn)

        bar.addView(tool("◀") { go(page + 1) })   // الصفحة اللي بعدها (عربي: السهم لليسار)
        pageLabel = TextView(this).apply { textSize = 16f; setPadding(dp(8), 0, dp(8), 0) }
        bar.addView(pageLabel)
        bar.addView(tool("▶") { go(page - 1) })
        bar.addView(tool("＋") { addPage() })
        bar.addView(tool("🗑") {
            android.app.AlertDialog.Builder(this)
                .setMessage("تمسحي كل اللي في الصفحة دي؟")
                .setPositiveButton("مسح") { _, _ -> canvas.clearAll() }
                .setNegativeButton("إلغاء", null).show()
        })

        root.addView(HorizontalScrollView(this).apply {
            setBackgroundColor(0xFFF1F3F8.toInt()); addView(bar)
        })
        root.addView(canvas, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        go(0)
        refreshTools()
    }

    private fun tool(label: String, color: Int = Color.BLACK, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label; textSize = 22f; setTextColor(color); gravity = Gravity.CENTER
            minWidth = dp(46); minHeight = dp(46)
            setPadding(dp(6), 0, dp(6), 0)
            setOnClickListener { onClick() }
        }

    private fun highlight(v: TextView, on: Boolean) {
        v.background = if (on) GradientDrawable().apply {
            setColor(0xFFD6E4FF.toInt()); cornerRadius = dp(10).toFloat()
        } else null
    }

    private fun refreshTools() {
        highlight(penBtn, !canvas.eraser)
        highlight(eraserBtn, canvas.eraser)
        highlight(fingerBtn, canvas.fingerDraw)
    }

    private fun go(i: Int) {
        if (i < 0 || i >= note.pages.size) return
        page = i
        canvas.strokes = note.pages[i]
        pageLabel.text = "${page + 1}/${note.pages.size}"
    }

    private fun addPage() {
        note.pages.add(page + 1, mutableListOf())
        go(page + 1)
    }

    private fun saveNow() { Store.save(this, note) }

    override fun onPause() { super.onPause(); if (::note.isInitialized) saveNow() }
}
